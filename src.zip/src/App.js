import React from 'react';
import logo from './logo.svg';
import './App.css';
import React from "react";
import ReactDOM from "react-dom";
import Highlighter from "react-highlight-words";
import txt from './wordtxt.svg';


function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={txt} className="App-logo" alt="logo" />
        <p>
          ReactDOM.render(
			  <Highlighter
				highlightClassName="YourHighlightClass"
				searchWords={["occurrence"]}
				autoEscape={true}
			  />,
			  document.getElementById("root")
			);
        </p>
	   
      </header>
    </div>
  );
} 

export default App;
